<?php
$ch = curl_init();

$json = file_get_contents('php://input');
$date = json_decode($json,TRUE);

$from_date = $date['from'];
$to_data = $date['to'];



$from = strtotime($from_date);
$to = strtotime($to_data);
curl_setopt($ch, CURLOPT_URL, 'https://api.razorpay.com/v1/payments?count=100&from='.$from.'&to='.$to);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, 'rzp_test_5hVqkkkrdrMqfT' . ':' . '5tRq3ejRG0t9AcabE3f5jiHZ');

$result = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
$response = json_decode($result, TRUE);
$response_count = $response['count'];

echo $response_count;


?>
