<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class External extends CI_Controller {

	public function __construct() {
	        parent::__construct();
	}
	
	public function login_token(){
	      $curl = curl_init();
	      curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://apiv2.shiprocket.in/v1/external/auth/login',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "email": "technology@amalaearth.com",
            "password": "Amala123456"
          }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
          ));
        
        $response = curl_exec($curl);
    
        curl_close($curl);
        $response = json_decode($response, TRUE);
        $token = $response['token'];
        return $token;
	}
	
	public function shiprocket(){
	    $token = $this->login_token();
	    $json = file_get_contents('php://input');
        $shipment_id = json_decode($json,TRUE);
        $shipment_id = $shipment_id['shipment_id'];
        $curl = curl_init();
        if(isset($shipment_id) && $shipment_id){
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://apiv2.shiprocket.in/v1/external/shipments/'.$shipment_id,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$token.''
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        $response = json_decode($response, TRUE);
        $this->shipRocketkelsaUpload($response);
        }else{
            echo 'N/A';
        }
	}
	
	public function shiprocket_update(){
	    $token = $this->login_token();
	    $json = file_get_contents('php://input');
        $details = json_decode($json,TRUE);
        $shipment_id = $details['shipment_id'];
        $lead_id = $details['lead_id'];
        $curl = curl_init();
        if(isset($shipment_id) && $shipment_id && isset($lead_id) && $lead_id){
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://apiv2.shiprocket.in/v1/external/shipments/'.$shipment_id,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$token.''
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        $response = json_decode($response, TRUE);
        $this->shipRocketkelsaUpdate($response, $lead_id);
        }else{
            echo 'N/A';
        }
	}
	
	public function payment(){
	    $ch = curl_init();

        $json = file_get_contents('php://input');
        $date = json_decode($json,TRUE);
        
        $from_date = $date['from'];
        $to_data = $date['to'];
        $from = strtotime($from_date);
        $to = strtotime($to_data);
        curl_setopt($ch, CURLOPT_URL, 'https://api.razorpay.com/v1/payments?count=100&from='.$from.'&to='.$to);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        
        curl_setopt($ch, CURLOPT_USERPWD, 'rzp_test_5hVqkkkrdrMqfT' . ':' . '5tRq3ejRG0t9AcabE3f5jiHZ');
        
        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        $response = json_decode($result, TRUE);
        $response_count = $response['count'];
        if(isset($response_count) && $response_count > 0){
         foreach ($response['items'] as $value) {
          $this->kelsaUpload($value);
          sleep(5);
         }
        }
	}
	
	public function single_payment(){
	    $ch = curl_init();

        $json = file_get_contents('php://input');
        $details = json_decode($json,TRUE);
        $payment_id = $details['payment_id'];
        $lead_id = $details['lead_id'];
        
        curl_setopt($ch, CURLOPT_URL, 'https://api.razorpay.com/v1/payments/'.$payment_id);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        
        curl_setopt($ch, CURLOPT_USERPWD, 'rzp_test_5hVqkkkrdrMqfT' . ':' . '5tRq3ejRG0t9AcabE3f5jiHZ');
        
        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        $response = json_decode($result, TRUE);
        $this->single_payment_update($lead_id, $response);
        echo json_encode($response);
        
	}
	
	public function single_payment_update($lead_id, $value){
    	    $ch = curl_init();
    		$date = date('Y/m/d H:i:s', $value['created_at']);
    
            $jayParsedAry = [
                   "lead" => [
                         "custom_field_values" => [
                            "name" => $value['id'], 
                            "entity" => $value['entity'], 
                            "amount" => $value['amount'], 
                            "currency" => $value['currency'], 
                            "status1" =>  $value['status'], 
                            "order_id" => $value['order_id'], 
                            "invoice_id" => $value['invoice_id'], 
                            "international1" => $value['international'], 
                            "method1" =>  $value['method'],
                            "amount_refunded" => $value['amount_refunded'],
                            "refund_status1" => $value['refund_status'],
                            "captured1" => $value['captured'],
                            "description" => $value['description'],
                            "card_id" => $value['card_id'],
                            "bank" => $value['bank'], 
                            "wallet" => $value['wallet'],
                            "vpa" => $value['vpa'], 
                            "email" => $value['email'],
                            "contact" => $value['contact'],
                            "notes" => $value['notes'], 
                            "fee" => $value['fee'], 
                            "tax" => $value['tax'], 
                            "error_code" => $value['error_code'], 
                            "error_description" => $value['error_description'], 
                            "error_source" => $value['error_source'],
                            "error_step" => $value['error_step'], 
                            "error_reason" => $value['error_reason'], 
                            "acquirer_data" => $value['acquirer_data'],
                            "auth_code" => $value['acquirer_data']['auth_code'],
                            "payment_date" => $date
                         ] 
                      ] 
                ]; 
			$data_string = json_encode($jayParsedAry);
		    $url =  "https://kelsa.io/7633/api/v1/leads/".$lead_id;
		    curl_setopt($ch, CURLOPT_URL,$url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
		    $headers = array();
			$headers[] = "Content-Type:".HEADER_CONTENT;
			$headers[] = "X-User-Email:".HEADER_EMAIL;
			$headers[] = "X-User-Token:".HEADER_TOKEN;
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			$result = curl_exec($ch);
	}
	
	public function kelsaUpload($value){
	       $date = date('Y/m/d H:i:s', $value['created_at']);
    
            $jayParsedAry = [
                   "lead" => [
                         "custom_field_values" => [
                            "name" => $value['id'], 
                            "entity" => $value['entity'], 
                            "amount" => $value['amount'], 
                            "currency" => $value['currency'], 
                            "status1" =>  $value['status'], 
                            "order_id" => $value['order_id'], 
                            "invoice_id" => $value['invoice_id'], 
                            "international1" => $value['international'], 
                            "method1" =>  $value['method'],
                            "amount_refunded" => $value['amount_refunded'],
                            "refund_status1" => $value['refund_status'],
                            "captured1" => $value['captured'],
                            "description" => $value['description'],
                            "card_id" => $value['card_id'],
                            "bank" => $value['bank'], 
                            "wallet" => $value['wallet'],
                            "vpa" => $value['vpa'], 
                            "email" => $value['email'],
                            "contact" => $value['contact'],
                            "notes" => $value['notes'], 
                            "fee" => $value['fee'], 
                            "tax" => $value['tax'], 
                            "error_code" => $value['error_code'], 
                            "error_description" => $value['error_description'], 
                            "error_source" => $value['error_source'],
                            "error_step" => $value['error_step'], 
                            "error_reason" => $value['error_reason'], 
                            "acquirer_data" => $value['acquirer_data'],
                            "auth_code" => $value['acquirer_data']['auth_code'],
                            "payment_date" => $date
                         ] 
                      ] 
                ]; 
                
        
			$ch = curl_init();
			$data_string = json_encode($jayParsedAry);
		    $url =  "https://kelsa.io/7633/api/v1/leads";
		    curl_setopt($ch, CURLOPT_URL,$url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
		    $headers = array();
			$headers[] = "Content-Type:".HEADER_CONTENT;
			$headers[] = "X-User-Email:".HEADER_EMAIL;
			$headers[] = "X-User-Token:".HEADER_TOKEN;
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			$result = curl_exec($ch);    
			echo json_encode($result);
 
    }
    
    
    public function shipRocketkelsaUpload($value){

             $jayParsedAry = [
               "lead" => [
                     "custom_field_values" => [
                        "name" => $value['data']['id'], 
                        "order_id" => $value['data']['order_id'], 
                        "channel_id" => $value['data']['channel_id'], 
                        "company_id" => $value['data']['company_id'], 
                        "invoice_no" => $value['data']['invoice_no'], 
                        "invoice_date" => $value['data']['invoice_date'], 
                        "courier" => $value['data']['courier'], 
                        "sr_courier_id" => $value['data']['sr_courier_id'], 
                        "awb" => $value['data']['awb'], 
                        "awb_assign_date" => $value['data']['awb_assign_date'], 
                        "pickup_generated_date" => $value['data']['pickup_generated_date'], 
                        "pickup_token_number" => $value['data']['pickup_token_number'], 
                        "method" => $value['data']['method'], 
                        "weight" => $value['data']['weight'], 
                        "dimensions" => $value['data']['dimensions'], 
                        "charges" => $value['data']['charges']['cod_charges'], 
                        "zone" => $value['data']['charges']['zone'], 
                        "cod_charges" => $value['data']['charges']['cod_charges'], 
                        "applied_weight_amount" => $value['data']['charges']['applied_weight_amount'] > 0 ? $value['data']['charges']['applied_weight_amount'] : 0, 
                        "freight_charges" => $value['data']['charges']['freight_charges'] > 0 ? $value['data']['charges']['freight_charges'] : 0, 
                        "applied_weight" => $value['data']['charges']['applied_weight'], 
                        "charged_weight" => $value['data']['charges']['charged_weight'], 
                        "charged_weight_amount" =>  $value['data']['charges']['charged_weight_amount'] > 0 ? $value['data']['charges']['charged_weight_amount'] : 0, 
                        "charged_weight_amount_rto" => $value['data']['charges']['charged_weight_amount_rto'], 
                        "applied_weight_amount_rto" => $value['data']['charges']['applied_weight_amount_rto'], 
                        "quantity" => $value['data']['quantity'], 
                        "cost" => $value['data']['cost'], 
                        "tax" => $value['data']['tax'], 
                        "cod_charges1" => $value['data']['cod_charges'], 
                        "total" => $value['data']['total'], 
                        "shipping_address" => $value['data']['shipping_address']['address'], 
                        "city" => $value['data']['shipping_address']['city'], 
                        "state" => $value['data']['shipping_address']['state'], 
                        "address" => $value['data']['shipping_address']['address'], 
                        "country" => $value['data']['shipping_address']['country'], 
                        "pincode" => $value['data']['shipping_address']['pincode'], 
                        "address_2" => $value['data']['shipping_address']['address_2'], 
                        "company_name" => $value['data']['shipping_address']['company_name'], 
                        "customer_details" => $value['data']['customer_details']['first_name'], 
                        "psid" => $value['data']['customer_details']['psid'], 
                        "phone" => $value['data']['customer_details']['phone'], 
                        "last_name" => $value['data']['customer_details']['last_name'], 
                        "first_name" => $value['data']['customer_details']['first_name'], 
                        "status" => $value['data']['status'], 
                        "shipped_date" => $value['data']['shipped_date'], 
                        "delivered_date" => $value['data']['delivered_date'], 
                        "returned_date" => $value['data']['returned_date'], 
                        "label_url" => $value['data']['label_url'], 
                        "manifest_url" => $value['data']['manifest_url'], 
                        "date" => $value['data']['created_at']['date'], 
                        "timezone_type" => $value['data']['created_at']['timezone_type'], 
                        "timezone" => $value['data']['created_at']['timezone'], 
                        "updated_at" => $value['data']['updated_at']['date'], 
                        "date1" => $value['data']['updated_at']['date'], 
                        "timezone_type1" => $value['data']['updated_at']['timezone_type'], 
                        "timezone1" => $value['data']['updated_at']['timezone']
                     ] 
                  ] 
            ]; 
                
        
			$ch = curl_init();
			$data_string = json_encode($jayParsedAry);
		    $url =  "https://kelsa.io/7634/api/v1/leads";
		    curl_setopt($ch, CURLOPT_URL,$url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
		    $headers = array();
			$headers[] = "Content-Type:".HEADER_CONTENT;
			$headers[] = "X-User-Email:".HEADER_EMAIL;
			$headers[] = "X-User-Token:".HEADER_TOKEN;
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			$result = curl_exec($ch);
    }
    
    
        public function shipRocketkelsaUpdate($value, $lead_id){

             $jayParsedAry = [
               "lead" => [
                     "custom_field_values" => [
                        "name" => $value['data']['id'], 
                        "order_id" => $value['data']['order_id'], 
                        "channel_id" => $value['data']['channel_id'], 
                        "company_id" => $value['data']['company_id'], 
                        "invoice_no" => $value['data']['invoice_no'], 
                        "invoice_date" => $value['data']['invoice_date'], 
                        "courier" => $value['data']['courier'], 
                        "sr_courier_id" => $value['data']['sr_courier_id'], 
                        "awb" => $value['data']['awb'], 
                        "awb_assign_date" => $value['data']['awb_assign_date'], 
                        "pickup_generated_date" => $value['data']['pickup_generated_date'], 
                        "pickup_token_number" => $value['data']['pickup_token_number'], 
                        "method" => $value['data']['method'], 
                        "weight" => $value['data']['weight'], 
                        "dimensions" => $value['data']['dimensions'], 
                        "charges" => $value['data']['charges']['cod_charges'], 
                        "zone" => $value['data']['charges']['zone'], 
                        "cod_charges" => $value['data']['charges']['cod_charges'], 
                        "applied_weight_amount" => $value['data']['charges']['applied_weight_amount'] > 0 ? $value['data']['charges']['applied_weight_amount'] : 0, 
                        "freight_charges" => $value['data']['charges']['freight_charges'] > 0 ? $value['data']['charges']['freight_charges'] : 0, 
                        "applied_weight" => $value['data']['charges']['applied_weight'], 
                        "charged_weight" => $value['data']['charges']['charged_weight'], 
                        "charged_weight_amount" =>  $value['data']['charges']['charged_weight_amount'] > 0 ? $value['data']['charges']['charged_weight_amount'] : 0, 
                        "charged_weight_amount_rto" => $value['data']['charges']['charged_weight_amount_rto'], 
                        "applied_weight_amount_rto" => $value['data']['charges']['applied_weight_amount_rto'], 
                        "quantity" => $value['data']['quantity'], 
                        "cost" => $value['data']['cost'], 
                        "tax" => $value['data']['tax'], 
                        "cod_charges1" => $value['data']['cod_charges'], 
                        "total" => $value['data']['total'], 
                        "shipping_address" => $value['data']['shipping_address']['address'], 
                        "city" => $value['data']['shipping_address']['city'], 
                        "state" => $value['data']['shipping_address']['state'], 
                        "address" => $value['data']['shipping_address']['address'], 
                        "country" => $value['data']['shipping_address']['country'], 
                        "pincode" => $value['data']['shipping_address']['pincode'], 
                        "address_2" => $value['data']['shipping_address']['address_2'], 
                        "company_name" => $value['data']['shipping_address']['company_name'], 
                        "customer_details" => $value['data']['customer_details']['first_name'], 
                        "psid" => $value['data']['customer_details']['psid'], 
                        "phone" => $value['data']['customer_details']['phone'], 
                        "last_name" => $value['data']['customer_details']['last_name'], 
                        "first_name" => $value['data']['customer_details']['first_name'], 
                        "status" => $value['data']['status'], 
                        "shipped_date" => $value['data']['shipped_date'], 
                        "delivered_date" => $value['data']['delivered_date'], 
                        "returned_date" => $value['data']['returned_date'], 
                        "label_url" => $value['data']['label_url'], 
                        "manifest_url" => $value['data']['manifest_url'], 
                        "date" => $value['data']['created_at']['date'], 
                        "timezone_type" => $value['data']['created_at']['timezone_type'], 
                        "timezone" => $value['data']['created_at']['timezone'], 
                        "updated_at" => $value['data']['updated_at']['date'], 
                        "date1" => $value['data']['updated_at']['date'], 
                        "timezone_type1" => $value['data']['updated_at']['timezone_type'], 
                        "timezone1" => $value['data']['updated_at']['timezone']
                     ] 
                  ] 
            ]; 
                
        
			$ch = curl_init();
			$data_string = json_encode($jayParsedAry);
		    $url =  "https://kelsa.io/7634/api/v1/leads/".$lead_id;
		    curl_setopt($ch, CURLOPT_URL,$url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
		    $headers = array();
			$headers[] = "Content-Type:".HEADER_CONTENT;
			$headers[] = "X-User-Email:".HEADER_EMAIL;
			$headers[] = "X-User-Token:".HEADER_TOKEN;
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			$result = curl_exec($ch);
    }

}