<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct() {
			parent::__construct();
			$this->load->library('encryption');
	}

	public function index()
	{
		$this->load->view('login');
	}

	public function onboarding()
	{
		$this->load->view('signup');
	}

	public function dashboard()
	{
		if(isset($_SESSION) && isset($_SESSION['user'])){
			$this->load->view('dashboard');
	    }else{
			redirect(base_url());
	    }
    }
    
    public function changepassword()
	{
		if(isset($_SESSION) && isset($_SESSION['user'])){
		    $current_password = $this->input->post('current_password');
	    	$new_password = $this->input->post('new_password');
	    	$ArrayResponse = array();
	    	$ch = curl_init();
				$url = 'https://kelsa.io/6681/api/v1/leads?search_query=cf_email_id:'.$_SESSION['user']['custom_field_values']['email_id'];
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
				$headers = array();
				$headers[] = "Content-Type:".HEADER_CONTENT;
				$headers[] = "X-User-Email:".HEADER_EMAIL;
				$headers[] = "X-User-Token:".HEADER_TOKEN;
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				$result = curl_exec($ch);
				$response = json_decode($result, true);
				if(isset($response) && isset($response['meta']['count']) && $response['meta']['count'] == 1){
					if(isset($response['leads']) && isset($response['leads'][0]) && $response['leads'][0]['custom_field_values']['email_id'] == $_SESSION['user']['custom_field_values']['email_id']){
						if($response['leads'][0]['custom_field_values']['password'] == md5($current_password.PWD_TOKEN)){
						        $this->updateLoginPassword($response['leads'][0],$new_password);
						        $this->updateChangePassword($response['leads'][0]);
						        $ArrayResponse['message'] = 'Correct Password';
						        $this->logout();
						} else{
								$ArrayResponse['message'] = 'Incorrect Current Password';
								$this->data['changeStatus'] = $ArrayResponse;
								$this->load->view('dashboard',$this->data);
						}
					}
				}
	    }else{
			redirect(base_url());
	    }
    }

public function bankdetails()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
		$ch = curl_init();
		$url = 'https://kelsa.io/6682/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response = json_decode($result, true);
		$this->data['bankdetails'] = $response;
		
		$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;
		
		$this->load->view('bank.php',$this->data);
    }else{
    		redirect(base_url());
    }
}


public function requestbox()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
	    	$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;
		$this->load->view('boxes.php',$this->data);
}else{
		redirect(base_url());
}
}

public function requestboxlist()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
		$ch = curl_init();
		$url = 'https://kelsa.io/6686/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response = json_decode($result, true);
		$this->data['request_boxes'] = $response;
		
		$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;
		$this->load->view('boxeslist.php',$this->data);
	}else{
		redirect(base_url());
 }
}

public function product()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
		$ch = curl_init();
		$url = 'https://kelsa.io/6676/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response = json_decode($result, true);
		$this->data['onboarding_details'] = $response;
		
		$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;
		
		$this->load->view('product',$this->data);
	}else{
			redirect(base_url());
	}
}


public function bulkproduct()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
		$ch = curl_init();
		$url = 'https://kelsa.io/6676/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response = json_decode($result, true);
		$this->data['onboarding_details'] = $response;
		
		$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;
		
		$this->load->view('bulkproduct',$this->data);
	}else{
			redirect(base_url());
	}
}


public function home()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
		$ch = curl_init();
		$url = 'https://kelsa.io/6672/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response = json_decode($result, true);
		$this->data['onboarding_details'] = $response;

		$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;


		$this->load->view('home',$this->data);
}else{
		redirect(base_url());
}
}

public function coupons()
{
	if(isset($_SESSION) && isset($_SESSION['user'])){
		$ch = curl_init();
		$url = 'https://kelsa.io/6719/api/v1/leads?search_query=cf_vendor_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response = json_decode($result, true);
		$this->data['product_list'] = $response;
		
		$ch = curl_init();
		$url = 'https://kelsa.io/6683/api/v1/leads?search_query=cf_email:'.$_SESSION['user']['custom_field_values']['email_id'];
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
		$headers = array();
		$headers[] = "Content-Type:".HEADER_CONTENT;
		$headers[] = "X-User-Email:".HEADER_EMAIL;
		$headers[] = "X-User-Token:".HEADER_TOKEN;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		$response_data = json_decode($result, true);
		$this->data['agreement_details'] = $response_data;
		
		$this->load->view('coupons',$this->data);
	}else{
		redirect(base_url());
	}
}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url());
	}

	public function login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$ArrayResponse = array();
		if(isset($username) && isset($password)){
				$ch = curl_init();
				$url = 'https://kelsa.io/6681/api/v1/leads?search_query=cf_email_id:'.$username;
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_TIMEOUT, 1000);
				$headers = array();
				$headers[] = "Content-Type:".HEADER_CONTENT;
				$headers[] = "X-User-Email:".HEADER_EMAIL;
				$headers[] = "X-User-Token:".HEADER_TOKEN;
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				$result = curl_exec($ch);
				$response = json_decode($result, true);
				if(isset($response) && isset($response['meta']['count']) && $response['meta']['count'] == 1){
					if(isset($response['leads'])&& isset($response['leads'][0]) && $response['leads'][0]['custom_field_values']['email_id'] == $username){
						if(isset($response['leads'][0]['custom_field_values']['first_sign_up']) && $response['leads'][0]['custom_field_values']['first_sign_up']['id'] == '320534' && $response['leads'][0]['custom_field_values']['password'] == $password){
								$this->updateLoginPassword($response['leads'][0],$password);
								$ArrayResponse['message'] = 'First Time';
								$_SESSION['user'] = $response['leads'][0];
							    redirect(base_url('Auth/dashboard'));
						} else if(isset($response['leads'][0]['custom_field_values']['first_sign_up']) && $response['leads'][0]['custom_field_values']['first_sign_up']['id'] == '320533' && $response['leads'][0]['custom_field_values']['password'] == md5($password.PWD_TOKEN)){
								$ArrayResponse['message'] = 'Correct Password';
								$_SESSION['user'] = $response['leads'][0];
								redirect(base_url('Auth/home'));
						}else{
								$ArrayResponse['message'] = 'Incorrect Password';
							redirect(base_url());
						}
					}else{
					$ArrayResponse['message'] = 'Something Went Wrong';
					$this->data['response'] = $ArrayResponse;
					redirect(base_url());
				}
				}else{
					$ArrayResponse['message'] = 'No User Found';
					$this->data['response'] = $ArrayResponse;
					redirect(base_url());
				}
	}else{
		$ArrayResponse['message'] = "Username & Password is mandatory";
		$this->data['response'] = $ArrayResponse;
		redirect(base_url());
	}
}

public function updateLoginPassword($lead,$password){

			$ch = curl_init();
			$json = [
				   "lead" => [
		       "custom_field_values" => [
						 	"first_sign_up" => [
											"name" => "true",
											"id" => 320533
									 ],
							"password" => md5($password.PWD_TOKEN)
		         ]
		      ]
				];
			$data_string = json_encode($json);
		    $url =  "https://kelsa.io/6681/api/v1/leads/".$lead['id'];
		    curl_setopt($ch, CURLOPT_URL,$url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
		    $headers = array();
			$headers[] = "Content-Type:".HEADER_CONTENT;
			$headers[] = "X-User-Email:".HEADER_EMAIL;
			$headers[] = "X-User-Token:".HEADER_TOKEN;
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			$result = curl_exec($ch);
}

public function updateChangePassword($lead){

			$ch = curl_init();
			$json = [
				   "lead" => [
		       "custom_field_values" => [
						 	"change_password" => [
											"name" => "true",
											"id" => 320676
									 ]
		             ]
		            ]
				];
			$data_string = json_encode($json);
		    $url =  "https://kelsa.io/6681/api/v1/leads/".$lead['id'];
		    curl_setopt($ch, CURLOPT_URL,$url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		    curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
		    $headers = array();
			$headers[] = "Content-Type:".HEADER_CONTENT;
			$headers[] = "X-User-Email:".HEADER_EMAIL;
			$headers[] = "X-User-Token:".HEADER_TOKEN;
		    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			$result = curl_exec($ch);
}


}
