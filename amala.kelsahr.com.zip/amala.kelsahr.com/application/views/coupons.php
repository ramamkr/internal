<!--
=========================================================
* Material Dashboard Dark Edition - v2.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-dark
* Copyright 2019 Creative Tim (http://www.creative-tim.com)

* Coded by www.creative-tim.com

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url('painter/assets/img/apple-icon.png')?>">
  <link rel="icon" type="image/png" href="<?php echo base_url('painter/assets/img/favicon.png')?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>

  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="<?php echo base_url('painter/assets/css/material-dashboard.css?v=2.1.0')?>" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo base_url('painter/assets/demo/demo.css')?>" rel="stylesheet" />
  <link href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css" rel="stylesheet" />
  <style>
  .dark-edition .sidebar[data-color="purple"] li.active>a {
    background: linear-gradient(195deg, #a48b6d 0%, #a48b6d 100%)!important;
    box-shadow: 0 4px 20px 0px rgb(0 0 0 / 14%), 0 7px 10px -5px rgb(58 55 58 / 40%);
}
.dark-edition .card .card-header-primary:not(.card-header-icon):not(.card-header-text){
  background: linear-gradient(60deg, #a48b6d, #a48b6d)!important;
}
.card .card-header-primary:not(.card-header-icon):not(.card-header-text){
  box-shadow: 0 4px 20px 0px rgb(0 0 0 / 14%), 0 7px 10px -5px rgb(34 32 34 / 40%);

}
.sidebar[data-background-color="black"] .nav .nav-item .nav-link {
    color: #fff;
    font-weight: 600;
}

.dark-edition .sidebar .logo .simple-text {
    color: white;
    font-weight: bold;
}
.dark-edition .table>thead>tr>th{
  color:white;
}
.table>tbody>tr>td{
  color: white;
}

 .buttons-csv {
    background:white!important;
}
.dataTables_wrapper .dataTables_filter input{
 color:white!important;   
}
.table>tbody>tr>td{
    color:white!important;
}
#example_paginate{
    color:white!important;
}
  </style>
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="black" data-image="../painter/assets/img/sidebar-2.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="" class="simple-text logo-normal">
          <img  style="width: 70px;height: 70px;text-align: center;" src="https://kelsa-clients-production.s3.ap-south-1.amazonaws.com/uploads/accounts/588/files/8856a9eb-a368-4516-ad8f-82e14235e1cf/1648044606867.jpg"/> &nbsp; Amala Earth
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
             <?php if(isset($_SESSION['user']['custom_field_values']['change_password']['id']) && $_SESSION['user']['custom_field_values']['change_password']['id'] == '320676') {?>
          <li class="nav-item  ">
            <a class="nav-link" href="<?php echo base_url('Auth/home') ?>">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <?php } ?>
          <li class="nav-item  ">
            <a class="nav-link" href="<?php echo base_url('Auth/dashboard') ?>">
              <i class="material-icons">person</i>
              <p>Company Profile</p>
            </a>
          </li>
 <?php if(isset($_SESSION['user']['custom_field_values']['change_password']['id']) && $_SESSION['user']['custom_field_values']['change_password']['id'] == '320676') {?>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url('Auth/product') ?>">
              <i class="material-icons">list</i>
              <p>Add Products</p>
            </a>
          </li>
          
          <!-- <li class="nav-item">-->
          <!--  <a class="nav-link" href="<?php echo base_url('Auth/bulkproduct') ?>">-->
          <!--    <i class="material-icons">list</i>-->
          <!--    <p>Upload Bulk Products</p>-->
          <!--  </a>-->
          <!--</li>-->

          <li class="nav-item active">
            <a class="nav-link" href="<?php echo base_url('Auth/coupons') ?>">
              <i class="material-icons">list</i>
              <p>Products List</p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url('Auth/bankdetails') ?>">
              <i class="material-icons">list</i>
              <p>Bank Details</p>
            </a>
          </li>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url('Auth/requestbox') ?>">
                <i class="material-icons">list</i>
                <p>Request for Boxes</p>
            </a>
          </li>

          <li class="nav-item  ">
            <a class="nav-link" href="<?php echo base_url('Auth/requestboxlist') ?>">
                <i class="material-icons">list</i>
                <p>Request Boxes Status</p>
            </a>
          </li>
<?php } ?>

          <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url('Auth/logout') ?>">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
          <!-- <li class="nav-item active-pro ">
                <a class="nav-link" href="./upgrade.html">
                    <i class="material-icons">unarchive</i>
                    <p>Upgrade to PRO</p>
                </a>
            </li> -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top " id="navigation-example">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:void(0)">Product List</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation" data-target="#navigation-example">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">


          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Product Lists</h4>

                </div>
                <div class="card-body">
                 <?php if(isset($agreement_details)  && $agreement_details['meta']['count'] > 0 && $agreement_details['leads'][0]['custom_field_values']['approval_status']['id'] == '320600') { ?>    
                  <div class="table-responsive">
                    <table class="table" id="example">
                      <thead class=" text-primary">
                        <th>
                         Reference ID
                        </th>
                        <th>
                          Product Name
                        </th>
                        
                         <th>
                          Price
                        </th>
                        <th>
                          Approval Status
                        </th>
                        <th>
                          View Details
                        </th>
                      </thead>
                      <tbody>
                        <?php foreach($product_list['leads'] as $list){ ?>
                        <tr>
                          <td>
                            <?php echo $list['id'] ?>
                          </td>
                          <td>
                            <?php echo $list['custom_field_values']['product_title'] ?>
                          </td>
                            <td>
                                
                            <?php 
                            if(isset($list['custom_field_values']['selling_proce'])){
                                echo $list['custom_field_values']['selling_proce'] ;
                                }else{
                                    echo '--';
                                }?>
                          </td>
                          <td>
                            <?php echo $list['custom_field_values']['approval_status']['name'] ?>
                          </td>
                          <td>
                            <p>N/A</p>
                          </td>

                        </tr>
                      <?php } ?>

                      </tbody>
                    </table>
                  </div>
                  <?php } else { ?>
                        <p style="color:white;">Please Complete the onboarding process / onboaridng process is Under Verification</p>
                    <?php } ?>
                </div>
              </div>
            </div>

        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">

        </div>
      </footer>
      <script>
        const x = new Date().getFullYear();
        let date = document.getElementById('date');
        date.innerHTML = '&copy; ' + x + date.innerHTML;
      </script>
    </div>
  </div>

  <!--   Core JS Files   -->
  <script src="<?php echo base_url('painter/assets/js/core/jquery.min.js')?>"></script>
  <script src="<?php echo base_url('painter/assets/js/core/popper.min.js')?>"></script>
  <script src="<?php echo base_url('painter/assets/js/core/bootstrap-material-design.min.js')?>"></script>
  <script src="https://unpkg.com/default-passive-events"></script>
  <script src="<?php echo base_url('painter/assets/js/plugins/perfect-scrollbar.jquery.min.js')?>"></script>
  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="<?php echo base_url('painter/assets/js/plugins/chartist.min.js')?>"></script>
  <!--  Notifications Plugin    -->
  <script src="<?php echo base_url('painter/assets/js/plugins/bootstrap-notify.js')?>"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo base_url('painter/assets/js/material-dashboard.js?v=2.1.0')?>"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?php echo base_url('painter/assets/demo/demo.js')?>"></script>
  <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
 <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
 <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'csvHtml5',
        ]
    } );
} );
</script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
</body>

</html>
